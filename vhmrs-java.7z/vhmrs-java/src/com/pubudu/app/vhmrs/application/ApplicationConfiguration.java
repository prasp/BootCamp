package com.pubudu.app.vhmrs.application;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.pubudu.app.vhmrs.repository.EmployeeRepository;
import com.pubudu.app.vhmrs.repository.HibernateEmployeeRepositoryImpl;
import com.pubudu.app.vhmrs.service.EmployeeService;
import com.pubudu.app.vhmrs.service.EmployeeServiceImpl;

@Configuration
@ComponentScan("com.pubudu")
public class ApplicationConfiguration {

	@Bean(name="employeeService")
	@Scope("prototype")
	public EmployeeService getEmployeeService(){
		
		EmployeeServiceImpl employeeService = new EmployeeServiceImpl();
		employeeService.setEmployeeRepository(getEmployeeRepository());
		return employeeService;
	
	}
	
	@Bean(name="employeeRepository")
	public EmployeeRepository getEmployeeRepository(){
		return new HibernateEmployeeRepositoryImpl();
	}
	
	
	
	
}
