package com.pubudu.app.vhmrs.application;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.pubudu.app.vhmrs.model.Employee;
import com.pubudu.app.vhmrs.service.EmployeeService;
import com.pubudu.app.vhmrs.service.EmployeeServiceImpl;

public class Application {

	public static void main(String args[]) {
		
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
		
		
		EmployeeService employeeService = applicationContext.getBean("employeeService",EmployeeService.class);
		
		System.out.println(employeeService.toString());
		
		EmployeeService employeeService2 = applicationContext.getBean("employeeService",EmployeeService.class);
		
		System.out.println(employeeService2.toString());
		
		
		List<Employee> employees = employeeService.getAllEmployees();
		
		for(Employee employee:employees){
			System.out.println(employee.getName() + " From " + employee.getLocation());
		}		
		// TODO Auto-generated method stub

	}

}