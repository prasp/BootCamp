package com.pubudu.app.vhmrs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import com.pubudu.app.vhmrs.model.Employee;
import com.pubudu.app.vhmrs.repository.EmployeeRepository;
import com.pubudu.app.vhmrs.repository.HibernateEmployeeRepositoryImpl;

public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeRepository employeeRepository;// = new HibernateEmployeeRepositoryImpl();
	
	@Autowired
	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		System.out.println("Call the Implemented Constructor");
		this.employeeRepository = employeeRepository;
	}
	
	@Autowired
	public EmployeeServiceImpl() {
		System.out.println("Default Constructor");
	}
	
	public EmployeeRepository getEmployeeRepository() {
		return employeeRepository;
	}

	public void setEmployeeRepository(EmployeeRepository employeeRepository) {
		this.employeeRepository = employeeRepository;
	}

	@Override
	public List<Employee> getAllEmployees(){
		return employeeRepository.getAllEmployees();
	}

	
	
	
}
