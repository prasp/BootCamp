package com.pubudu.app.vhmrs.service;

import java.util.List;

import com.pubudu.app.vhmrs.model.Employee;

public interface EmployeeService {

	List<Employee> getAllEmployees(); 
	
}
