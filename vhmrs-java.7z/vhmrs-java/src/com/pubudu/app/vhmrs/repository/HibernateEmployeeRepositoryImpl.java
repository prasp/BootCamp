package com.pubudu.app.vhmrs.repository;

import java.util.ArrayList;
import java.util.List;

import org.omg.CORBA.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

import com.pubudu.app.vhmrs.model.Employee;

public class HibernateEmployeeRepositoryImpl implements EmployeeRepository {
	
	
	//@Autowired
	//Environment environment;
	//String city = environment.getProperty("city");
	
	
	//@Value(${city})
	//String city;
	
	public List<Employee> getAllEmployees() {
		
		
		// TODO Auto-generated method stub
		List<Employee> employees  = new ArrayList();
		Employee E1 = new Employee();
		E1.setName("Pubudu");
		E1.setLocation("Nugegoda");
		
		employees.add(E1);
		return employees;
	}

}
