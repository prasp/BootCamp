package com.pubudu;

import org.hibernate.Session;

import com.pubudu.hibernate.HibernateUtil;
import com.pubudu.model.Employee;

public class Application {
	
	
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		System.out.println("Session opened");
		
		session.beginTransaction();
		Employee employee = new Employee();
		employee.setName("Somaweera");
		employee.setCity("Colombo");
		employee.setAge(60);
		
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		
		System.out.println("Saved");
		
		
	}

	
}
