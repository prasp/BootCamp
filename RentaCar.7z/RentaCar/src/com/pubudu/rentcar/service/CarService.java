package com.pubudu.rentcar.service;

import java.util.List;

import com.pubudu.rentcar.model.Car;

public interface CarService {
	Car save(Car car);
	
	public List<Car> findByMake(String make);
}
