package com.pubudu.rentcar.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pubudu.rentcar.model.Car;
import com.pubudu.rentcar.repository.CarRepository;

@Service
public class CarServiceImpl implements CarService{

	@Autowired
	CarRepository carRepository;
	@Override
	public Car save(Car car) {
		// TODO Auto-generated method stub
		return carRepository.save(car);
	}
	
	
	public List<Car> findByMake(String make){
		return carRepository.findByMake(make);
	}
}
