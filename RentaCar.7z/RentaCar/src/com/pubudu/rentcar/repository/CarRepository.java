package com.pubudu.rentcar.repository;


import java.util.List;

import org.springframework.data.repository.Repository;

import com.pubudu.rentcar.model.Car;

public interface CarRepository extends Repository<Car,Integer>{
	Car save(Car car);
	
	List<Car> findByMake(String make);
	
	
}
