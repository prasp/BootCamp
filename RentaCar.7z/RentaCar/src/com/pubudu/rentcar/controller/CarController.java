package com.pubudu.rentcar.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pubudu.rentcar.model.Car;
import com.pubudu.rentcar.service.CarService;

@RestController
public class CarController {

	@Autowired
	CarService carservice;
	
	@RequestMapping(value = "/car" ,method = RequestMethod.POST)
	public void save(@RequestBody Car car){
		
		carservice.save(car);
	}
	
	@RequestMapping(value = "/car" ,method = RequestMethod.GET)
	public List<Car> findByMake(@RequestParam("make") String make){
		
		return carservice.findByMake(make);
	}
	
	
	
	
}
