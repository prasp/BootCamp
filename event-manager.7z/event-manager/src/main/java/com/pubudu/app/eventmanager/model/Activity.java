package com.pubudu.app.eventmanager.model;

public class Activity {

	private String activityName;

	
	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
}
