package com.pubudu.app.eventmanager.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pubudu.app.eventmanager.model.Activity;

@Controller
public class ActivityController{
	
	@RequestMapping(value="/greeting")
	public String getWelcomeMessage(Model model){
		System.out.println("entered to controller");
		model.addAttribute("message", "Hi Spring MVC you look handy!!!!!!!!!");
		return "welcome";
	}
	
	@RequestMapping(value="/addActivity")
	public String addActivity(@ModelAttribute("activities") Activity activity){
		//System.out.println(activity.getActivityName());
		if(activity.getActivityName() == null){
			return "addActivity";
		}else{
			System.out.println(activity.getActivityName());
			//call the service the from Bank we use redirect
			return "redirect:addSubActivity.html";
		}
	}
	
	@RequestMapping(value="/addSubActivity")
	public String addSubActivity(@ModelAttribute("activities") Activity activity){
		System.out.println("Sub activity is " +activity.getActivityName());
		return "addActivity";
	}
	
	
	
	
}
