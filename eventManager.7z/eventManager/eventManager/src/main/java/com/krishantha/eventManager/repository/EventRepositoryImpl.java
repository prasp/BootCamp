package com.krishantha.eventManager.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.krishantha.eventManager.model.Event;

@Repository("eventRepository")
public class EventRepositoryImpl implements EventRepository{

	
	@PersistenceContext
	EntityManager enityManager;
	
	public Event save(Event event) {
		// TODO Auto-generated method stub
		enityManager.persist(event);
		enityManager.flush();
		return event;
	}

	public List<Event> fetchAllEvents() {
		Query query = enityManager.createQuery("select e from Event e");
		List<Event> events = query.getResultList();
		System.out.println("aaaaaaaaaaa"+events.size());
		return events;
	}

}
