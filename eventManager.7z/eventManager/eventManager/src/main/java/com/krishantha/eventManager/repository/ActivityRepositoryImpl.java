package com.krishantha.eventManager.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.krishantha.eventManager.model.Activity;

@Repository("activityRepository")
public class ActivityRepositoryImpl implements ActivityRepository{

	@PersistenceContext
	EntityManager enityManager;
	public Activity Save(Activity activity) {
		// TODO Auto-generated method stub
		enityManager.persist(activity);
		enityManager.flush();
		
		return activity;
	}

}
