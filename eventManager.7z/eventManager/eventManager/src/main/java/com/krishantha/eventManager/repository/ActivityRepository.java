package com.krishantha.eventManager.repository;

import com.krishantha.eventManager.model.Activity;

public interface ActivityRepository {
	Activity Save(Activity activity);
}
