package com.krishantha.eventManager.model;

public class EventType {
	
	String eventType;

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

}
