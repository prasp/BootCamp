package com.virtusa.training.client;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;



public class TrainingClient {

	public static void main(String[] args) throws MalformedURLException, IOException {
		URL redmine = new URL("http://ramdesh.m.redmine.org/projects.xml");
        URLConnection connection = redmine.openConnection();
        connection.addRequestProperty("X-Redmine-API-Key", "0bcce325ec4158ecea594aeeb391175366472f31");
        BufferedReader in = new BufferedReader(new InputStreamReader(
                                    connection.getInputStream()));
        String inputLine;
        while ((inputLine = in.readLine()) != null) 
            System.out.println(inputLine);
        in.close();

	}

}
