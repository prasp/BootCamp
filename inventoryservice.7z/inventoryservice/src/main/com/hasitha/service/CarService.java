package main.com.hasitha.service;

import java.util.List;

import main.com.hasitha.model.Car;

public interface CarService {

	public Car save(Car car);
	
	List<Car> findByMake(String make);
	
	
}
