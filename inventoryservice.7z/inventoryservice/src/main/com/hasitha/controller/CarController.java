package main.com.hasitha.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import main.com.hasitha.model.Car;
import main.com.hasitha.service.CarService;

@Controller
public class CarController {
	
	@Autowired
	CarService carService;
	
	@RequestMapping(value="/car", method= RequestMethod.POST)
	public void save(@RequestBody Car car){
		carService.save(car);
		System.out.println("okkkkk");
	}
	
	@RequestMapping(value="/car", method= RequestMethod.GET)
	public List<Car> findByMake(@RequestParam("make") String make){
		
		return carService.findByMake(make);
		
	}

}
