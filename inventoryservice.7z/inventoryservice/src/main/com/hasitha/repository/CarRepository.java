package main.com.hasitha.repository;

import java.util.List;

import org.springframework.data.repository.Repository;

import main.com.hasitha.model.Car;

public interface CarRepository extends Repository<Car, Integer>{
	
	Car save(Car car);
	
	List<Car> findByMake(String make);

}
