package main.com.hasitha.repository;

public class CarRepositoryImpl {

}
