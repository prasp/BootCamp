package com.pubudu.app.vhmrs.repository;

import java.util.ArrayList;
import java.util.List;

import com.pubudu.app.vhmrs.model.Employee;

public class HibernateEmployeeRepositoryImpl implements EmployeeRepository {

	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		List<Employee> employees  = new ArrayList();
		
		Employee E1 = new Employee();
		
		
		E1.setName("Pubudu");
		E1.setLocation("Nugegoda");
		
		employees.add(E1);
		return employees;
	}

}
