package com.pubudu.app.vhmrs.service;

import java.util.List;

import com.pubudu.app.vhmrs.model.Employee;
import com.pubudu.app.vhmrs.repository.EmployeeRepository;
import com.pubudu.app.vhmrs.repository.HibernateEmployeeRepositoryImpl;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeRepository employeeRepository;// = new HibernateEmployeeRepositoryImpl();
	
	
	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		System.out.println("constructor injected");
		this.employeeRepository = employeeRepository;
	}
	
	public EmployeeRepository getEmployeeRepository() {
		return employeeRepository;
	}

	public void setEmployeeRepository(EmployeeRepository employeeRepository) {
		System.out.println("setter injected");
		this.employeeRepository = employeeRepository;
	}
	
	
	
	
	

	@Override
	public List<Employee> getAllEmployees(){
		return employeeRepository.getAllEmployees();
	}

	
	
	
}
