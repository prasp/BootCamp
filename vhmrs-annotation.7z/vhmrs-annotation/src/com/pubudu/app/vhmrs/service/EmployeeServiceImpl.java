package com.pubudu.app.vhmrs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pubudu.app.vhmrs.model.Employee;
import com.pubudu.app.vhmrs.repository.EmployeeRepository;
import com.pubudu.app.vhmrs.repository.HibernateEmployeeRepositoryImpl;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService{

	
	//Member variable injecttion spring use reflection for this
	
	@Autowired
	EmployeeRepository employeeRepository;// = new HibernateEmployeeRepositoryImpl();
	
	@Autowired
	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		System.out.println("Setter based injection");
		this.employeeRepository = employeeRepository;
	}

	public EmployeeRepository getEmployeeRepository() {
		return employeeRepository;
	}
	
	@Autowired
	public void setEmployeeRepository(EmployeeRepository employeeRepository) {
		System.out.println("Constructor is called");
		this.employeeRepository = employeeRepository;
	}

	
	
	
	
	@Override
	public List<Employee> getAllEmployees(){
		return employeeRepository.getAllEmployees();
	}

	
	
	
}
