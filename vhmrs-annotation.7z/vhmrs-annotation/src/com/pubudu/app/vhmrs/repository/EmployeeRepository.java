package com.pubudu.app.vhmrs.repository;

import java.util.List;

import com.pubudu.app.vhmrs.model.Employee;

public interface EmployeeRepository {

	List<Employee> getAllEmployees(); 
}
